import axios from "axios";

const CUSTOMMER_API_BASE_URL ="http://localhost:8080/api/v1/custommers"

class CustommerService {
    getCustommers(){
        return axios.get(CUSTOMMER_API_BASE_URL);
    }

    postCustommer(custommer){
        return axios.post(CUSTOMMER_API_BASE_URL, custommer);
    }

    getCustommerById(custommerId){
        return axios.get(CUSTOMMER_API_BASE_URL+'/'+custommerId);
    }

    updateCustommer(custommer, custommerId) {
        return axios.put(CUSTOMMER_API_BASE_URL +'/'+ custommerId, custommer);
    }

    deleteCustommer(custommerId){
        return axios.delete(CUSTOMMER_API_BASE_URL + '/' + custommerId);
    }

}

export default new CustommerService()