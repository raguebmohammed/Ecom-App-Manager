import React from 'react';
import './App.css';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom';
import FooterComponent from './components/FooterComponent';
import HeaderComponent from './components/HeaderComponent';
import ListCustommerComponent from './components/ListCustommerComponent';
import ListProductComponent from './components/ListProductComponent';
import AddOrUpdateCustommerComponent from './components/AddOrUpdateCustommerComponent';
import AddOrUpdateProductComponent from './components/AddOrUpdateProductComponent';
import HomeComponent from './components/HomeComponent';
import ViewCustommerComponent from './components/ViewCustommerComponent';
import ViewProductComponent from './components/ViewProductComponent';

function App() {
  return (
    <div>
      <Router>
      <HeaderComponent />
        <div className="container">
          <Switch>
          <Route path ='/home'  component= {HomeComponent}></Route>
          <Route path ='/Custommers'  component= {ListCustommerComponent}></Route>
          <Route path ='/products'  component= {ListProductComponent}></Route>
          <Route path ='/add-custommer/:id'   component= {AddOrUpdateCustommerComponent}></Route>
          <Route path ='/add-product/:id'   component= {AddOrUpdateProductComponent}></Route>
          <Route path ='/view-custommer/:id'   component= {ViewCustommerComponent}></Route>
          <Route path ='/view-product/:id'   component= {ViewProductComponent}></Route>
          </Switch>
        </div>
      <FooterComponent />
      </Router>
    </div>
  );
}

export default App;
