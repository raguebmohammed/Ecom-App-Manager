import React, { Component } from 'react';
import CustommerService from '../Services/CustommerService';

class ViewCustommerComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            id: this.props.match.params.id,
            custommer: {}
        }
    }

    componentDidMount(){
        CustommerService.getCustommerById(this.state.id).then( res => {
            this.setState({custommer: res.data});
        })
    }

    render() {
        return (
            <div>
                <br></br>
                <div className = "card col-md-6 offset-md-3">
                    <h3 className = "text-center"> View Custommer Details</h3>
                    <div className = "card-body">
                        <div className = "row">
                            <label> Custommer Full Name: </label>
                            <div> { this.state.custommer.fullname }</div>
                        </div>
                        <div className = "row">
                            <label> Custommer Phone Number: </label>
                            <div> { this.state.custommer.phonenumber }</div>
                        </div>
                        <div className = "row">
                            <label> Custommer Email : </label>
                            <div> { this.state.custommer.email }</div>
                        </div>
                        <div className = "row">
                            <label> Custommer Address: </label>
                            <div> { this.state.custommer.address }</div>
                        </div>
                        <div className = "row">
                            <label> Custommer Username: </label>
                            <div> { this.state.custommer.username }</div>
                        </div>
                        <div className = "row">
                            <label> Custommer Password: </label>
                            <div> { this.state.custommer.password }</div>
                        </div>
                    </div>

                </div>
            </div>
        );
    }
}

export default ViewCustommerComponent;