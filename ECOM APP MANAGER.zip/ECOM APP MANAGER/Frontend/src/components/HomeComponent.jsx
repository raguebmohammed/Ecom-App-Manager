import React, { Component } from 'react';
import ListCustommerComponent from './ListCustommerComponent';
import ListProductComponent from './ListProductComponent';

class HomeComponent extends Component {
    render() {
        return (
            <div>
                <ListCustommerComponent/>
                <ListProductComponent/>
            </div>
        );
    }
}

export default HomeComponent;