import React, { Component } from 'react';
import ProductService from '../Services/ProductService';

class AddOrUpdateProductComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            id: this.props.match.params.id,
            productname:'',
            nich:'',
            price:'',
            discountprice:'',

        }
        this.ChangeproductnameHandler = this.ChangeproductnameHandler.bind(this);
        this.ChangenichHandler = this.ChangenichHandler.bind(this);
        this.ChangepriceHandler = this.ChangepriceHandler.bind(this);
        this.ChangediscountpriceHandler = this.ChangediscountpriceHandler.bind(this);
        this.saveOrUpdateProduct = this.saveOrUpdateProduct.bind(this);
        this.cancel = this.cancel.bind(this);
    }

    componentDidMount(){

        if(this.state.id === '_add'){
            return
        }else{
            ProductService.getProductById(this.state.id).then( (res) =>{
                let product = res.data;
                this.setState({productname: product.productname, nich: product.nich, price: product.price,
                    discountprice: product.discountprice
                });
            });
        }        
    }

    saveOrUpdateProduct = (e) => {
        e.preventDefault();
        let product = {productname: this.state.productname, nich: this.state.nich, price: this.state.price, 
            discountprice: this.state.discountprice};
        console.log('product => ' + JSON.stringify(product));

        if(this.state.id === '_add'){
            ProductService.postProduct(product).then(res =>{
                this.props.history.push('/products');
            });
        }else{
            ProductService.updateProduct(product, this.state.id).then( res => {
                this.props.history.push('/products');
            });
        }
    }

    ChangeproductnameHandler= (event) => {
        this.setState({productname: event.target.value});
    }
    ChangenichHandler= (event) => {
        this.setState({nich: event.target.value});
    }
    ChangepriceHandler= (event) => {
        this.setState({price: event.target.value});
    }
    ChangediscountpriceHandler= (event) => {
        this.setState({discountprice: event.target.value});
    }
    saveProduct = (e) => {
        e.preventDefault();
        let product = {productname: this.state.productname, nich: this.state.nich, price: this.state.price, 
            discountprice: this.state.discountprice};
        console.log('product => '+ JSON.stringify(product));

        ProductService.postProduct(product).then(res => {
            this.props.history.push('/products');
        });

    }

    cancel(){
        this.props.history.push('/products');
    }


    getTitle(){
        if(this.state.id === '_add'){
            return <h3 className="text-center">Add Product</h3>
        }else{
            return <h3 className="text-center">Edit Product</h3>
        }
    }

    render() {
        return (
<div>
                <div className='container'>
                    <div className='row'>
                        <div className='card col-md-6 offset-md-3 offset-md-3'>
                        {
                                this.getTitle()
                            }
                            <div>
                                <form>
                                    <div className='form-group'>
                                        <label>Product Name:</label>
                                        <input placeholder='productname' name='productname' className='form-control'
                                        value={this.state.productname} onChange={this.ChangeproductnameHandler}/>
                                    </div>
                                    <div className='form-group'>
                                        <label>Nich:</label>
                                        <input placeholder='nich' name='nich' className='form-control'
                                        value={this.state.nich} onChange={this.ChangenichHandler}/>
                                    </div>
                                    <div className='form-group'>
                                        <label>Price:</label>
                                        <input placeholder='price' name='price' className='form-control'
                                        value={this.state.price} onChange={this.ChangepriceHandler}/>
                                    </div>
                                    <div className='form-group'>
                                        <label>Discount Price:</label>
                                        <input placeholder='discountprice' name='discountprice' className='form-control'
                                        value={this.state.discountprice} onChange={this.ChangediscountpriceHandler}/>
                                    </div>
                                    <button className='btn btn-success' onClick={this.saveOrUpdateProduct}>Save</button>
                                    <button className='btn btn-danger' onClick={this.cancel} style={{marginLeft:'10px'}}>Cancel</button>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        );
    }
}

export default AddOrUpdateProductComponent