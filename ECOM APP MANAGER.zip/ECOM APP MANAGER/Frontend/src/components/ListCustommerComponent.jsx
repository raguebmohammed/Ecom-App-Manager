import React, { Component } from 'react';
import CustommerService from '../Services/CustommerService';


class ListCustommerComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            custommers: []

        }
        this.editCustommer = this.editCustommer.bind(this);
        this.deleteCustommer = this.deleteCustommer.bind(this);
        this.addCustommer = this.addCustommer.bind(this);
    }

    deleteCustommer(id){
        CustommerService.deleteCustommer(id).then( res => {
            this.setState({custommers: this.state.custommers.filter(custommer => custommer.id !== id)});
        });
    }
    viewCustommer(id){
        this.props.history.push(`/view-custommer/${id}`);
    }

    editCustommer(id){
        this.props.history.push(`/add-custommer/${id}`);
    }

    componentDidMount(){
        CustommerService.getCustommers().then((res) => {
            this.setState({custommers: res.data});

        });
    }

    addCustommer(){
        this.props.history.push('/add-custommer/_add');
    }

    render() {
        return (
            <div>
                <h2 className='text-center'>Custommers List</h2>
                <div className='row'>
                   <button className="btn btn-primary" onClick={this.addCustommer}> Add Custommer</button>
                </div>
                <div className='row'></div>
                  <table className='table table striped table-bordered'>
                    <thead>
                        <tr>
                            <th>FullName</th>
                            <th>PhoneNumber</th>
                            <th>Email</th>
                            <th>Address</th>
                            <th>Username</th>
                            <th>Password</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        {
                            this.state.custommers.map(
                                custommer =>
                                <tr key = {custommer.id}>
                                    <td> {custommer.fullname}</td>
                                    <td> {custommer.phonenumber}</td>
                                    <td> {custommer.email}</td>
                                    <td> {custommer.address}</td>
                                    <td> {custommer.username}</td>
                                    <td> {custommer.password}</td>
                                    <td>
                                    <button onClick={ () => this.editCustommer(custommer.id)} className='btn btn-info'>Edit</button>
                                    <button style={{marginLeft: "10px"}} onClick={ () => this.deleteCustommer(custommer.id)} className="btn btn-danger">Delete </button>
                                    <button style={{marginLeft: "10px"}} onClick={ () => this.viewCustommer(custommer.id)} className="btn btn-info">View </button>
                                    </td>
                                </tr>
                            )
                        }
                    </tbody>
                </table>
            </div>
        );
    }
}

export default ListCustommerComponent;