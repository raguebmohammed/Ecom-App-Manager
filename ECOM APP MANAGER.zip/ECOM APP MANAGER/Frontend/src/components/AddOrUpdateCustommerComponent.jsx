import React, { Component } from 'react';
import CustommerService from '../Services/CustommerService';

class AddOrUpdateCustommerComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            id: this.props.match.params.id,
            fullname:'',
            phonenumber:'',
            email:'',
            address:'',
            username:'',
            password:''

        }
        this.ChangefullnameHandler = this.ChangefullnameHandler.bind(this);
        this.ChangephonenumberHandler = this.ChangephonenumberHandler.bind(this);
        this.ChangeemailHandler = this.ChangeemailHandler.bind(this);
        this.ChangeaddressHandler = this.ChangeaddressHandler.bind(this);
        this.ChangeusernameHandler = this.ChangeusernameHandler.bind(this);
        this.ChangepasswordHandler = this.ChangepasswordHandler.bind(this);
        this.saveOrUpdateCustommer = this.saveOrUpdateCustommer.bind(this);
        this.cancel = this.cancel.bind(this);

    }

    componentDidMount(){

        if(this.state.id === '_add'){
            return
        }else{
            CustommerService.getCustommerById(this.state.id).then( (res) =>{
                let custommer = res.data;
                this.setState({fullname: custommer.fullname, phonenumber: custommer.phonenumber, email: custommer.email,
                    address: custommer.address, username: custommer.username, password: custommer.password
                });
            });
        }        
    }

    saveOrUpdateCustommer = (e) => {
        e.preventDefault();
        let custommer = {fullname: this.state.fullname, phonenumber: this.state.phonenumber, email: this.state.email, 
            address: this.state.address, username: this.state.username, password: this.state.password};
        console.log('custommer => ' + JSON.stringify(custommer));

        if(this.state.id === '_add'){
            CustommerService.postCustommer(custommer).then(res =>{
                this.props.history.push('/custommers');
            });
        }else{
            CustommerService.updateCustommer(custommer, this.state.id).then( res => {
                this.props.history.push('/custommers');
            });
        }
    }

    ChangefullnameHandler= (event) => {
        this.setState({fullname: event.target.value});
    }
    ChangephonenumberHandler= (event) => {
        this.setState({phonenumber: event.target.value});
    }
    ChangeemailHandler= (event) => {
        this.setState({email: event.target.value});
    }
    ChangeaddressHandler= (event) => {
        this.setState({address: event.target.value});
    }
    ChangeusernameHandler= (event) => {
        this.setState({username: event.target.value});
    }
    ChangepasswordHandler= (event) => {
        this.setState({password: event.target.value});
    }

    cancel(){
        this.props.history.push('/custommers');
    }

    getTitle(){
        if(this.state.id === '_add'){
            return <h3 className="text-center">Add Custommer</h3>
        }else{
            return <h3 className="text-center">Edit Custommer</h3>
        }
    }

    render() {
        return (
            <div>
                <div className='container'>
                    <div className='row'>
                        <div className='card col-md-6 offset-md-3 offset-md-3'>
                            {
                                this.getTitle()
                            }
                            <div>
                                <form>
                                    <div className='form-group'>
                                        <label>FullName:</label>
                                        <input placeholder='fullname' name='fullname' className='form-control'
                                        value={this.state.fullname} onChange={this.ChangefullnameHandler}/>
                                    </div>
                                    <div className='form-group'>
                                        <label>Phone Number:</label>
                                        <input placeholder='phonenumber' name='phonenumber' className='form-control'
                                        value={this.state.phonenumber} onChange={this.ChangephonenumberHandler}/>
                                    </div>
                                    <div className='form-group'>
                                        <label>Email:</label>
                                        <input placeholder='email' name='email' className='form-control'
                                        value={this.state.email} onChange={this.ChangeemailHandler}/>
                                    </div>
                                    <div className='form-group'>
                                        <label>Address:</label>
                                        <input placeholder='address' name='address' className='form-control'
                                        value={this.state.address} onChange={this.ChangeaddressHandler}/>
                                    </div>
                                    <div className='form-group'>
                                        <label>Username:</label>
                                        <input placeholder='username' name='username' className='form-control'
                                        value={this.state.username} onChange={this.ChangeusernameHandler}/>
                                    </div>
                                    <div className='form-group'>
                                        <label>Password:</label>
                                        <input placeholder='password' name='password' className='form-control'
                                        value={this.state.password} onChange={this.ChangepasswordHandler}/>
                                    </div>
                                    <button className='btn btn-success' onClick={this.saveOrUpdateCustommer}>Save</button>
                                    <button className='btn btn-danger' onClick={this.cancel} style={{marginLeft:'10px'}}>Cancel</button>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        );
    }
}

export default AddOrUpdateCustommerComponent