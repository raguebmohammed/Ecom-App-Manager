package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "product")
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "productname")
    private String productname;

    @Column(name = "nich")
    private String nich;

    @Column(name = "price")
    private Float price;

    @Column(name = "discountprice")
    private Float discountprice;

    public Product() {
    }

    public Product(String productname, String nich, Float price,
                     Float discountprice) {
        super();
        this.productname = productname;
        this.nich = nich;
        this.price = price;
        this.discountprice = discountprice;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname;
    }

    public String getNich() {
        return nich;
    }

    public void setNich(String nich) {
        this.nich = nich;
    }

    public Float getPrice() {
        return price;
    }

    public void setPrice(Float price) {
        this.price = price;
    }

    public Float getDiscountprice() {
        return discountprice;
    }

    public void setDiscountprice(Float discountprice) {
        this.discountprice = discountprice;
    }
}
