package com.example.demo.config;

import com.example.demo.model.Product;
import com.example.demo.repository.ProductRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class ProductConfig {

    @Bean
    CommandLineRunner pcommandLineRunner(
            ProductRepository prepository) {
        return args -> {
            Product product1 = new Product(
                    "Ball",
                    "Sports",
                    20.00f,
                    0.00f
            );
            Product product2 = new Product(
                    "Spoon",
                    "Kitchen",
                    5.00f,
                    0.00f
            );

            prepository.saveAll(
                    List.of(product1, product2)
            );
        };
    }
}