package com.example.demo.config;

import com.example.demo.model.Custommer;
import com.example.demo.repository.CustommerRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class CustommerConfig {
    @Bean
    CommandLineRunner ccommandLineRunner(
            CustommerRepository crepository) {
        return args -> {
            Custommer custommer1 = new Custommer(
                   "anass khallouki",
                    "0665748392",
                    "anass.khallouki@gmail.com",
                    "sidi maarouf  21",
                    "anasskh",
                    "hkssana"
            );
            Custommer custommer2 = new Custommer(
                    "hind touzani",
                    "0647382649",
                    "hind.tzn@gmail.com",
                    "bernoussi  54",
                    "hindtzn",
                    "nztdnih"
            );
            crepository.saveAll(
                    List.of(custommer1, custommer2)
            );
        };
    }
}